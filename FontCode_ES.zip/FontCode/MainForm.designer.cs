namespace NotePLUS
{
    partial class MainForm
    {
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblLines, lblChars, lblLanguage;
        private System.Windows.Forms.ContextMenuStrip ctxEditor, ctxPestaña, ctxVacio;
        private System.Windows.Forms.ToolStripMenuItem menuArchivo, menuEdicion, menuCodigo, menuTema, menuLang, menuAyuda;
		private System.Windows.Forms.ToolStripStatusLabel lblEncoding;

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ctxEditor = new System.Windows.Forms.ContextMenuStrip();
            this.ctxPestaña = new System.Windows.Forms.ContextMenuStrip();
            this.ctxVacio = new System.Windows.Forms.ContextMenuStrip();

            // Status Strip
            this.lblLines = new System.Windows.Forms.ToolStripStatusLabel { Text = "Lineas: 0" };
            this.lblChars = new System.Windows.Forms.ToolStripStatusLabel { Text = "Chars: 0" };
            this.lblLanguage = new System.Windows.Forms.ToolStripStatusLabel { Text = "Texto plano" };
			this.lblEncoding = new System.Windows.Forms.ToolStripStatusLabel { 
    Text = "UTF-8", 
    BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left 
};

            // --- MENU CONTEXTUAL PESTAÑA ---
            this.ctxPestaña.Items.Add("Renombrar...", null, menuTabRenombrar_Click);
            this.ctxPestaña.Items.Add("Eliminar", null, menuTabEliminar_Click);
            this.tabControl1.ContextMenuStrip = this.ctxPestaña;

            // --- MENU CONTEXTUAL EDITOR (TEXTO) ---
            this.ctxEditor.Items.Add("Copiar", null, (s,e) => GetCurrentFCTB().Copy());
            this.ctxEditor.Items.Add("Pegar", null, (s,e) => GetCurrentFCTB().Paste());
            this.ctxEditor.Items.Add("Cortar", null, (s,e) => GetCurrentFCTB().Cut());

            // --- MENU CONTEXTUAL VACIO (Dando click al fondo o tabControl) ---
            this.ctxVacio.Items.Add("Seleccionar todo", null, (s,e) => GetCurrentFCTB().SelectAll());
            this.ctxVacio.Items.Add("Modo oscuro", null, (s,e) => SetDarkMode(true));
            this.ctxVacio.Items.Add("Modo claro", null, (s,e) => SetDarkMode(false));
            this.ctxVacio.Items.Add("Nueva pestaña", null, menuArchivoNuevo_Click);
            this.ctxVacio.Items.Add("Guardar", null, menuArchivoGuardar_Click);

            // --- MENU ARCHIVO ---
            menuArchivo = new System.Windows.Forms.ToolStripMenuItem("Archivo");
            menuArchivo.DropDownItems.Add("Nuevo", null, menuArchivoNuevo_Click);
            menuArchivo.DropDownItems.Add("Abrir", null, menuArchivoAbrir_Click);
            menuArchivo.DropDownItems.Add("Guardar", null, menuArchivoGuardar_Click);
            menuArchivo.DropDownItems.Add("Guardar como...", null, menuArchivoGuardarComo_Click);
            menuArchivo.DropDownItems.Add(new System.Windows.Forms.ToolStripSeparator());
            menuArchivo.DropDownItems.Add("Salir", null, (s,e) => System.Windows.Forms.Application.Exit());

            // --- MENU EDICION ---
            menuEdicion = new System.Windows.Forms.ToolStripMenuItem("Edicion");
            menuEdicion.DropDownItems.Add("Buscar...", null, (s,e) => GetCurrentFCTB().ShowFindDialog());
            var itSel = new System.Windows.Forms.ToolStripMenuItem("Seleccionar todo", null, (s,e) => GetCurrentFCTB().SelectAll());
            itSel.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E;
            menuEdicion.DropDownItems.Add(itSel);
            
            var menuFuente = new System.Windows.Forms.ToolStripMenuItem("Fuente...");
            menuFuente.DropDownItems.Add("Consolas", null, (s,e) => CambiarFuente("Consolas"));
            menuFuente.DropDownItems.Add("Segoe UI", null, (s,e) => CambiarFuente("Segoe UI"));
            menuFuente.DropDownItems.Add("Webdings", null, (s,e) => CambiarFuente("Webdings"));
            menuEdicion.DropDownItems.Add(menuFuente);

            menuEdicion.DropDownItems.Add(new System.Windows.Forms.ToolStripSeparator());
            var itCop = new System.Windows.Forms.ToolStripMenuItem("Copiar", null, (s,e) => GetCurrentFCTB().Copy());
            itCop.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C;
            menuEdicion.DropDownItems.Add(itCop);
            var itPeg = new System.Windows.Forms.ToolStripMenuItem("Pegar", null, (s,e) => GetCurrentFCTB().Paste());
            itPeg.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V;
            menuEdicion.DropDownItems.Add(itPeg);
            menuEdicion.DropDownItems.Add("Cortar", null, (s,e) => GetCurrentFCTB().Cut());

            // --- MENU CODIGO ---
            menuCodigo = new System.Windows.Forms.ToolStripMenuItem("Codigo");
            string[] lgs = { "CSharp", "Python", "HTML", "JS", "CSS", "PHP", "SQL", "C++" };
            foreach(string l in lgs) {
                var it = new System.Windows.Forms.ToolStripMenuItem(l);
                it.Click += delegate { ConfigurarLenguaje(l); };
                menuCodigo.DropDownItems.Add(it);
            }

            // --- MENU TEMA / LANG / AYUDA ---
            menuTema = new System.Windows.Forms.ToolStripMenuItem("Tema");
            menuTema.DropDownItems.Add("Editor claro", null, (s,e) => SetDarkMode(false));
            menuTema.DropDownItems.Add("Editor oscuro", null, (s,e) => SetDarkMode(true));

            menuLang = new System.Windows.Forms.ToolStripMenuItem("Lenguaje (LANG)");
            menuLang.DropDownItems.Add("English", null, (s,e) => CambiarIdioma("EN"));
            menuLang.DropDownItems.Add("Spanish", null, (s,e) => CambiarIdioma("ES"));

            menuAyuda = new System.Windows.Forms.ToolStripMenuItem("Ayuda");
            menuAyuda.DropDownItems.Add("Licencia...", null, (s,e) => AbrirDoc("license.txt"));
            menuAyuda.DropDownItems.Add("Acerca de...", null, (s,e) => AbrirDoc("about.txt"));
            menuAyuda.DropDownItems.Add("Uso...", null, (s,e) => AbrirDoc("use.txt"));

            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { menuArchivo, menuEdicion, menuCodigo, menuTema, menuLang, menuAyuda });
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblLines, lblChars, lblLanguage });
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblLines, lblChars, lblEncoding, lblLanguage });
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;

        }
    }
}