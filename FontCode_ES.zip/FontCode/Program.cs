using System;
using System.Windows.Forms;

namespace NotePLUS
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Si hay un argumento (un archivo), lo pasamos al constructor
            if (args.Length > 0)
                Application.Run(new MainForm(args[0]));
            else
                Application.Run(new MainForm(null));
        }
    }
}