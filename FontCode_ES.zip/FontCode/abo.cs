using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace NotePLUS_About
{
    public class AboutForm : Form
    {
        public AboutForm()
        {
            this.Text = "Acerca de NotePLUS";
            this.Size = new Size(500, 400);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            try {
                // El icono puede estar en la raíz o dentro de la carpeta
                if (File.Exists("iconabo.ico")) this.Icon = new Icon("iconabo.ico");
            } catch { }

            TabControl tabs = new TabControl { Dock = DockStyle.Fill };
            
            // Especificamos la ruta con la carpeta "about"
            tabs.TabPages.Add(CreateTabPage("Acerca de", "about\\about.txt"));
            tabs.TabPages.Add(CreateTabPage("Licencia", "about\\license.txt"));
            tabs.TabPages.Add(CreateTabPage("Uso", "about\\use.txt"));

            this.Controls.Add(tabs);
        }

        private TabPage CreateTabPage(string title, string relativePath)
        {
            TabPage tp = new TabPage(title);
            TextBox tb = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 10),
                BackColor = Color.White
            };

            // Combinamos la ruta base del programa con la ruta relativa del archivo
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);

            if (File.Exists(fullPath)) {
                tb.Text = File.ReadAllText(fullPath, Encoding.UTF8);
            } else {
                tb.Text = "Error: No se pudo encontrar el archivo en:\r\n" + fullPath;
            }

            tp.Controls.Add(tb);
            return tp;
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new AboutForm());
        }
    }
}