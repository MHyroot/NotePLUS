using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace NotePLUS_About
{
    public class AboutForm : Form
    {
        public AboutForm()
        {
            // Textos traducidos para la ventana principal de ayuda
            this.Text = "About NotePLUS"; 
            this.Size = new Size(500, 400);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            try {
                if (File.Exists("iconabo.ico")) this.Icon = new Icon("iconabo.ico");
            } catch { }

            TabControl tabs = new TabControl { Dock = DockStyle.Fill };
            
            // Se cambia la ruta a la carpeta "about_en" y se traducen los títulos de las pestañas
            tabs.TabPages.Add(CreateTabPage("About", "about_en\\about.txt"));
            tabs.TabPages.Add(CreateTabPage("License", "about_en\\license.txt"));
            tabs.TabPages.Add(CreateTabPage("Usage", "about_en\\use.txt"));

            this.Controls.Add(tabs);
        }

        private TabPage CreateTabPage(string title, string relativePath)
        {
            TabPage tp = new TabPage(title);
            TextBox tb = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Consolas", 10),
                BackColor = Color.White
            };

            // Construcción de la ruta dinámica
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);

            if (File.Exists(fullPath)) {
                tb.Text = File.ReadAllText(fullPath, Encoding.UTF8);
            } else {
                // Mensaje de error traducido
                tb.Text = "Error: Could not find the file at:\r\n" + fullPath;
            }

            tp.Controls.Add(tb);
            return tp;
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new AboutForm());
        }
    }
}