namespace NotePLUS
{
    partial class MainForm
    {
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblLines, lblChars, lblLanguage;
        private System.Windows.Forms.ContextMenuStrip ctxEditor, ctxPestaña, ctxVacio;
        private System.Windows.Forms.ToolStripMenuItem menuArchivo, menuEdicion, menuCodigo, menuTema, menuLang, menuAyuda;
		private System.Windows.Forms.ToolStripStatusLabel lblEncoding;

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ctxEditor = new System.Windows.Forms.ContextMenuStrip();
            this.ctxPestaña = new System.Windows.Forms.ContextMenuStrip();
            this.ctxVacio = new System.Windows.Forms.ContextMenuStrip();

            // Status Strip
            this.lblLines = new System.Windows.Forms.ToolStripStatusLabel { Text = "Lines: 0" };
            this.lblChars = new System.Windows.Forms.ToolStripStatusLabel { Text = "Chars: 0" };
            this.lblLanguage = new System.Windows.Forms.ToolStripStatusLabel { Text = "Plain text" };
			this.lblEncoding = new System.Windows.Forms.ToolStripStatusLabel { 
                Text = "UTF-8", 
                BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left 
            };

            // --- MENU CONTEXTUAL PESTAÑA ---
            this.ctxPestaña.Items.Add("Rename...", null, menuTabRenombrar_Click);
            this.ctxPestaña.Items.Add("Delete", null, menuTabEliminar_Click);
            this.tabControl1.ContextMenuStrip = this.ctxPestaña;

            // --- MENU CONTEXTUAL EDITOR (TEXTO) ---
            this.ctxEditor.Items.Add("Copy", null, (s,e) => GetCurrentFCTB().Copy());
            this.ctxEditor.Items.Add("Paste", null, (s,e) => GetCurrentFCTB().Paste());
            this.ctxEditor.Items.Add("Cut", null, (s,e) => GetCurrentFCTB().Cut());

            // --- MENU CONTEXTUAL VACIO (Dando click al fondo o tabControl) ---
            this.ctxVacio.Items.Add("Select all", null, (s,e) => GetCurrentFCTB().SelectAll());
            this.ctxVacio.Items.Add("Dark mode", null, (s,e) => SetDarkMode(true));
            this.ctxVacio.Items.Add("Light mode", null, (s,e) => SetDarkMode(false));
            this.ctxVacio.Items.Add("New tab", null, menuArchivoNuevo_Click);
            this.ctxVacio.Items.Add("Save", null, menuArchivoGuardar_Click);

            // --- MENU ARCHIVO ---
            menuArchivo = new System.Windows.Forms.ToolStripMenuItem("File");
            menuArchivo.DropDownItems.Add("New", null, menuArchivoNuevo_Click);
            menuArchivo.DropDownItems.Add("Open", null, menuArchivoAbrir_Click);
            menuArchivo.DropDownItems.Add("Save", null, menuArchivoGuardar_Click);
            menuArchivo.DropDownItems.Add("Save as...", null, menuArchivoGuardarComo_Click);
            menuArchivo.DropDownItems.Add(new System.Windows.Forms.ToolStripSeparator());
            menuArchivo.DropDownItems.Add("Exit", null, (s,e) => System.Windows.Forms.Application.Exit());

            // --- MENU EDICION ---
            menuEdicion = new System.Windows.Forms.ToolStripMenuItem("Edit");
            menuEdicion.DropDownItems.Add("Find...", null, (s,e) => GetCurrentFCTB().ShowFindDialog());
            var itSel = new System.Windows.Forms.ToolStripMenuItem("Select all", null, (s,e) => GetCurrentFCTB().SelectAll());
            itSel.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E;
            menuEdicion.DropDownItems.Add(itSel);
            
            var menuFuente = new System.Windows.Forms.ToolStripMenuItem("Font...");
            menuFuente.DropDownItems.Add("Consolas", null, (s,e) => CambiarFuente("Consolas"));
            menuFuente.DropDownItems.Add("Segoe UI", null, (s,e) => CambiarFuente("Segoe UI"));
            menuFuente.DropDownItems.Add("Webdings", null, (s,e) => CambiarFuente("Webdings"));
            menuEdicion.DropDownItems.Add(menuFuente);

            menuEdicion.DropDownItems.Add(new System.Windows.Forms.ToolStripSeparator());
            var itCop = new System.Windows.Forms.ToolStripMenuItem("Copy", null, (s,e) => GetCurrentFCTB().Copy());
            itCop.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C;
            menuEdicion.DropDownItems.Add(itCop);
            var itPeg = new System.Windows.Forms.ToolStripMenuItem("Paste", null, (s,e) => GetCurrentFCTB().Paste());
            itPeg.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V;
            menuEdicion.DropDownItems.Add(itPeg);
            menuEdicion.DropDownItems.Add("Cut", null, (s,e) => GetCurrentFCTB().Cut());

            // --- MENU CODIGO ---
            menuCodigo = new System.Windows.Forms.ToolStripMenuItem("Code");
            string[] lgs = { "CSharp", "Python", "HTML", "JS", "CSS", "PHP", "SQL", "C++" };
            foreach(string l in lgs) {
                var it = new System.Windows.Forms.ToolStripMenuItem(l);
                it.Click += delegate { ConfigurarLenguaje(l); };
                menuCodigo.DropDownItems.Add(it);
            }

            // --- MENU TEMA / LANG / AYUDA ---
            menuTema = new System.Windows.Forms.ToolStripMenuItem("Theme");
            menuTema.DropDownItems.Add("Light editor", null, (s,e) => SetDarkMode(false));
            menuTema.DropDownItems.Add("Dark editor", null, (s,e) => SetDarkMode(true));

            menuLang = new System.Windows.Forms.ToolStripMenuItem("Language (LANG)");
            menuLang.DropDownItems.Add("English", null, (s,e) => CambiarIdioma("EN"));
            menuLang.DropDownItems.Add("Spanish", null, (s,e) => CambiarIdioma("ES"));

            menuAyuda = new System.Windows.Forms.ToolStripMenuItem("Help");
            menuAyuda.DropDownItems.Add("License...", null, (s,e) => AbrirDoc("license.txt"));
            menuAyuda.DropDownItems.Add("About...", null, (s,e) => AbrirDoc("about.txt"));
            menuAyuda.DropDownItems.Add("Usage...", null, (s,e) => AbrirDoc("use.txt"));

            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { menuArchivo, menuEdicion, menuCodigo, menuTema, menuLang, menuAyuda });
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblLines, lblChars, lblEncoding, lblLanguage });
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;

        }
    }
}