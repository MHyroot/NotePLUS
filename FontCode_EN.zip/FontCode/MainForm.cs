using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using FastColoredTextBoxNS;

namespace NotePLUS
{
    public partial class MainForm : Form
    {
        private int tabCount = 1;
        private string currentFilePath = null;

        public MainForm(string fileToOpen)
        {
            InitializeComponent();
            this.Size = new Size(900, 650);
            this.Text = "NotePLUS V4.5 - Professional Edition";
            
            try {
                string iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "icon.ico");
                if (File.Exists(iconPath)) {
                    this.Icon = new Icon(iconPath);
                    this.ShowIcon = true;
                }
            } catch { }

            // Si Windows nos manda un archivo, lo abrimos; si no, pestaña nueva
            if (!string.IsNullOrEmpty(fileToOpen) && File.Exists(fileToOpen)) {
                AbrirArchivoExterno(fileToOpen);
            } else {
                AddNewTab("new " + tabCount++);
            }
        }

        public void AddNewTab(string title)
        {
            TabPage tp = new TabPage(title);
            FastColoredTextBox fctb = new FastColoredTextBox();
            fctb.Dock = DockStyle.Fill;
            fctb.Font = new Font("Consolas", 11f);
            
            // Asignar el menú contextual del editor de texto
            fctb.ContextMenuStrip = this.ctxEditor;

            fctb.TextChanged += delegate { UpdateStatus(fctb); };
            fctb.SelectionChanged += delegate { UpdateStatus(fctb); };
            
            tp.Controls.Add(fctb);
            tabControl1.TabPages.Add(tp);
            tabControl1.SelectedTab = tp;
        }
		
		private void AbrirArchivoExterno(string path) {
            AddNewTab(Path.GetFileName(path));
            FastColoredTextBox f = GetCurrentFCTB();
            if (f != null) {
                f.Text = File.ReadAllText(path);
                currentFilePath = path;
            }
        }

        private void UpdateStatus(FastColoredTextBox fctb)
        {
            lblLines.Text = "Lines: " + fctb.LinesCount;
            lblChars.Text = "Chars: " + fctb.Text.Length;
            
            // Si el lenguaje es Custom o no está definido, mostrar Texto plano
            string lang = fctb.Language.ToString();
            if (lang == "Custom" || string.IsNullOrEmpty(lang))
                lblLanguage.Text = "Plain text";
            else
                lblLanguage.Text = lang;
        }

        private FastColoredTextBox GetCurrentFCTB()
        {
            if (tabControl1.SelectedTab != null && tabControl1.SelectedTab.Controls.Count > 0)
                return tabControl1.SelectedTab.Controls[0] as FastColoredTextBox;
            return null;
        }

        // --- Gestión de Fuentes ---
        private void CambiarFuente(string fontName)
        {
            FastColoredTextBox f = GetCurrentFCTB();
            if (f != null) f.Font = new Font(fontName, f.Font.Size);
        }

        // --- Lógica de Idioma ---
        private void CambiarIdioma(string lang)
        {
            bool es = (lang == "ES");
            menuArchivo.Text = es ? "Archivo" : "File";
            menuEdicion.Text = es ? "Edicion" : "Edit";
            menuCodigo.Text = es ? "Codigo" : "Code";
            menuTema.Text = es ? "Tema" : "Theme";
            menuAyuda.Text = es ? "Ayuda" : "Help";
        }

        // --- Soporte Funcional de Lenguajes ---
        public void ConfigurarLenguaje(string langName)
        {
            FastColoredTextBox f = GetCurrentFCTB();
            if (f == null) return;
            try {
                if (langName == "C++") f.Language = Language.CSharp;
                else if (langName == "Python") {
                    f.Language = Language.Custom; 
                    f.Language = Language.JS; 
                }
                else f.Language = (Language)Enum.Parse(typeof(Language), langName);
            } catch { f.Language = Language.Custom; }
            UpdateStatus(f);
        }

        // --- Acciones de Archivo ---
        private void menuArchivoNuevo_Click(object sender, EventArgs e) { AddNewTab("new " + tabCount++); }
        private void menuArchivoAbrir_Click(object sender, EventArgs e) {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK) {
                AddNewTab(Path.GetFileName(ofd.FileName));
                if (GetCurrentFCTB() != null) {
                    GetCurrentFCTB().Text = File.ReadAllText(ofd.FileName);
                    currentFilePath = ofd.FileName;
                }
            }
        }
        private void menuArchivoGuardar_Click(object sender, EventArgs e) {
            if (string.IsNullOrEmpty(currentFilePath)) menuArchivoGuardarComo_Click(sender, e);
            else if (GetCurrentFCTB() != null) File.WriteAllText(currentFilePath, GetCurrentFCTB().Text);
        }
        private void menuArchivoGuardarComo_Click(object sender, EventArgs e) {
            SaveFileDialog sfd = new SaveFileDialog();
            if (sfd.ShowDialog() == DialogResult.OK) {
                if (GetCurrentFCTB() != null) {
                    File.WriteAllText(sfd.FileName, GetCurrentFCTB().Text);
                    currentFilePath = sfd.FileName;
                    tabControl1.SelectedTab.Text = Path.GetFileName(sfd.FileName);
                }
            }
        }

        // --- Lógica de Temas ---
        private void SetDarkMode(bool dark) {
            FastColoredTextBox f = GetCurrentFCTB();
            if (f == null) return;
            if (dark) {
                f.BackColor = Color.FromArgb(30,30,30); f.ForeColor = Color.White; f.CaretColor = Color.White;
            } else {
                f.BackColor = Color.White; f.ForeColor = Color.Black; f.CaretColor = Color.Black;
            }
        }

        // --- Otros métodos ---
        private void AbrirDoc(string parametro) 
        {
            try {
                if (File.Exists("abo_en.exe")) {
                    System.Diagnostics.Process.Start("abo_en.exe");
                } else if (File.Exists("abo.exe")) {
                    System.Diagnostics.Process.Start("abo.exe");
                } else {
                    if (File.Exists(parametro)) System.Diagnostics.Process.Start(parametro);
                }
            } catch {
                MessageBox.Show("Could not open the help information.");
            }
        }

        private void menuTabRenombrar_Click(object sender, EventArgs e) {
            string n = Microsoft.VisualBasic.Interaction.InputBox("Name:", "Rename", tabControl1.SelectedTab.Text);
            if (!string.IsNullOrEmpty(n)) tabControl1.SelectedTab.Text = n;
        }
        private void menuTabEliminar_Click(object sender, EventArgs e) {
            if (tabControl1.TabPages.Count > 1) tabControl1.TabPages.Remove(tabControl1.SelectedTab);
        }
    }
}