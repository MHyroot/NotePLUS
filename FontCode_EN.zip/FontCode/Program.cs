using System;
using System.Windows.Forms;

namespace NotePLUS
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // If there is an argument (a file), we pass it to the constructor
            if (args.Length > 0)
                Application.Run(new MainForm(args[0]));
            else
                Application.Run(new MainForm(null));
        }
    }
}